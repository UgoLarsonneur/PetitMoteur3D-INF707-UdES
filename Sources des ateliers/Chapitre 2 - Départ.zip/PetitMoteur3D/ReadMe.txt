========================================================================
    APPLICATION WIN32 : Vue d'ensemble du projet PetitMoteur3D
========================================================================

AppWizard a cr�� cette application PetitMoteur3D pour vous.  

Ce fichier contient un r�sum� du contenu de chacun des fichiers qui
constituent votre application PetitMoteur3D.


PetitMoteur3D.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g�n�r�s � l'aide d'un Assistant Application. 
    Il contient des informations sur la version de Visual C++ utilis�e pour g�n�rer le fichier, ainsi que des informations relatives aux plates-formes, configurations et fonctionnalit�s du projet que vous avez s�lectionn�es dans l'Assistant Application.

PetitMoteur3D.cpp
    Il s'agit du fichier source principal de l'application.

/////////////////////////////////////////////////////////////////////////////
AppWizard a cr�� les ressources suivantes :

PetitMoteur3D.rc
    Il s'agit de la liste de toutes les ressources Microsoft Windows que le
    programme utilise.  Elle comprend les ic�nes, les bitmaps et les curseurs qui sont stock�s
    dans le sous-r�pertoire RES.  Ce fichier peut �tre modifi� directement dans Microsoft
    Visual C++.

Resource.h
    Il s'agit du ficher d'en-t�te standard, qui d�finit les nouveaux ID de ressources.
    Microsoft Visual C++ lit et met � jour ce fichier.

PetitMoteur3D.ico
    Il s'agit d'un fichier ic�ne, qui est utilis� comme ic�ne de l'application (32x32).
    Cette
    ic�ne est incluse par le fichier de ressource principal PetitMoteur3D.rc.

small.ico
    Il s'agit d'un fichier ic�ne qui contient une version plus petite (16x16)
    de l'ic�ne de l'application. Cette ic�ne est incluse par le fichier de ressource
    principal PetitMoteur3D.rc.

/////////////////////////////////////////////////////////////////////////////
Autres fichiers standard :

StdAfx.h, StdAfx.cpp
    Ces fichiers sont utilis�s pour g�n�rer un fichier d'en-t�te pr�compil� (PCH)
    nomm� PetitMoteur3D.pch et un fichier de type pr�compil� nomm� StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Autres remarques :

AppWizard utilise des commentaires "TODO:" pour indiquer les parties du code source o�
vous devrez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
