#pragma once

#include "resource.h"
#include "moteur.h"
