//{{NO_DEPENDENCIES}}
// Fichier Include g�n�r� de Microsoft Visual C++.
// Utilis� par PetitMoteur3D.rc
//
#define IDC_MYICON                      2
#define IDD_PETITMOTEUR3D_DIALOG        102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define DXE_ERREURCREATIONDEVICE        104
#define IDM_EXIT                        105
#define DXE_ERREUROBTENTIONBUFFER       105
#define DXE_ERREURCREATIONRENDERTARGET  106
#define IDI_PETITMOTEUR3D               107
#define DXE_CREATION_VS                 107
#define IDI_SMALL                       108
#define DXE_FICHIER_VS                  108
#define IDC_PETITMOTEUR3D               109
#define DXE_CREATION_PS                 110
#define DXE_FICHIER_PS                  111
#define DXE_CREATIONVERTEXBUFFER        112
#define DXE_CREATIONINDEXBUFFER         113
#define DXE_CREATIONLAYOUT              114
#define DXE_ERREURCREATIONTEXTURE       115
#define DXE_ERREURCREATIONDEPTHSTENCILTARGET 116
#define DXE_ERREURCREATION_FX           117
#define DXE_FICHIERTEXTUREINTROUVABLE   118
#define DXE_ERREURCREATION_BLENDSTATE   119
#define ERREUR_CREATION_DIRECTINPUT     120
#define ERREUR_CREATION_CLAVIER         121
#define ERREUR_CREATION_FORMATCLAVIER   122
#define ERREUR_CREATION_SOURIS          123
#define ERREUR_CREATION_FORMATSOURIS    124
#define IDR_MAINFRAME                   128
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
